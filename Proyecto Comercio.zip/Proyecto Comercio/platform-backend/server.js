const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

const usersPath = path.join(__dirname, 'users.json');

// ✅ Ruta de registro
app.post('/register', (req, res) => {
  const { username, email, password, role } = req.body;

  if (!username || !email || !password || !role) {
    return res.status(400).json({ message: 'Todos los campos son obligatorios' });
  }

  if (password.length < 6) {
    return res.status(400).json({ message: 'La contraseña debe tener al menos 6 caracteres' });
  }

  let users = [];

  if (fs.existsSync(usersPath)) {
    users = JSON.parse(fs.readFileSync(usersPath));
  }

  const emailExists = users.find(u => u.email === email);
  if (emailExists) {
    return res.status(409).json({ message: 'El correo ya está registrado' });
  }

  const newUser = { id: Date.now(), username, email, password, role };
  users.push(newUser);
  fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));

  return res.status(200).json({ message: 'Usuario registrado exitosamente' });
});

// ✅ Ruta de login
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email y contraseña requeridos' });
  }

  if (!fs.existsSync(usersPath)) {
    return res.status(401).json({ message: 'No hay usuarios registrados aún' });
  }

  const users = JSON.parse(fs.readFileSync(usersPath));
  const user = users.find(u => u.email === email && u.password === password);

  if (!user) {
    return res.status(401).json({ message: 'Usuario o contraseña incorrectos' });
  }

  return res.status(200).json({
    message: 'Inicio de sesión exitoso',
    username: user.username,
    role: user.role
  });
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
