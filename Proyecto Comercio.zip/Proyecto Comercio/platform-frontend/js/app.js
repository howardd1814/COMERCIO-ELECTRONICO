// --- Referencias a secciones del DOM ---
const sections = {
  login: document.getElementById('login'),
  register: document.getElementById('register'),
  landing: document.getElementById('landing'),
  about: document.getElementById('about'),
  panel: document.getElementById('panel')
};

// --- Botones (si tienes logout más adelante) ---
const buttons = {
  logoutBtn: document.getElementById('logoutBtn')
};

// --- Función para mostrar una sola sección y ocultar las demás ---
function toggleSection(visibleId) {
  Object.keys(sections).forEach(id => {
    sections[id].classList.toggle('hidden', id !== visibleId);
  });
}

// --- Mostrar formulario de login ---
function showLogin() {
  toggleSection('login');
}

// --- Mostrar formulario de registro ---
function showRegister() {
  toggleSection('register');
}

// --- Volver a la landing principal ---
function returnToHome() {
  toggleSection('landing');
  if (buttons.logoutBtn) {
    buttons.logoutBtn.classList.add('hidden');
  }
}

// --- Cerrar sesión (volver al landing) ---
function logout() {
  returnToHome();
  alert('Sesión cerrada.');
}

// --- Scroll suave a sección "about" ---
function scrollToAbout() {
  sections.about.scrollIntoView({ behavior: 'smooth' });
}

// ==================== LOGIN ====================
document.getElementById('loginForm').addEventListener('submit', async e => {
  e.preventDefault();

  const email = e.target.username.value.trim();
  const password = e.target.password?.value || ''; // Por si aún no hay campo contraseña

  try {
    const res = await fetch('http://localhost:3000/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const result = await res.json();

    if (res.status === 200) {
      alert(`Bienvenido, ${result.username}`);
      toggleSection('panel');
      if (buttons.logoutBtn) {
        buttons.logoutBtn.classList.remove('hidden');
      }
    } else {
      alert(result.message);
    }
  } catch (err) {
    alert('Error en el servidor');
    console.error(err);
  }
});

// ==================== REGISTRO ====================
document.getElementById('registerForm').addEventListener('submit', async e => {
  e.preventDefault();

  const username = e.target.username.value.trim();
  const email = e.target.email.value.trim();
  const password = e.target.password.value;
  const role = e.target.role?.value || 'estudiante';

  if (!username || !email || !password) {
    alert('Todos los campos son obligatorios');
    return;
  }

  const data = { username, email, password, role };

  try {
    const res = await fetch('http://localhost:3000/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    const result = await res.json();

    if (res.status === 200) {
      alert(result.message);
      e.target.reset();
      toggleSection('login');
    } else {
      alert(result.message);
    }
  } catch (err) {
    alert('Error en el servidor');
    console.error(err);
  }
});

// ==================== SUBIDA DE PROYECTOS ====================
document.getElementById('uploadForm').addEventListener('submit', async e => {
  e.preventDefault();

  const projectName = e.target.projectName.value.trim();
  const description = e.target.description.value.trim();

  if (!projectName || !description) {
    alert('Completa todos los campos del proyecto.');
    return;
  }

  try {
    const res = await fetch('https://your-render-backend-url/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ projectName, description })
    });

    const result = await res.json();
    alert(result.message || 'Proyecto enviado correctamente');
    e.target.reset();
  } catch (err) {
    console.error('Error al subir proyecto:', err);
    alert('Error al subir el proyecto');
  }
});
